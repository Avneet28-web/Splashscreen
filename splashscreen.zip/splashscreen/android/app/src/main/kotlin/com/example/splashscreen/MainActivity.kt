package com.example.splashscreen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
